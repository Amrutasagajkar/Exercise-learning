package handleSyncIssue_ConditionalWait;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import utility.Constants;

public class ConditionalWaitElement {
	WebDriver driver;
	Logger log;
	
	@BeforeTest
	public void launchApp() throws Exception {
		
		
		//log configuration
		
		log = Logger.getLogger("nopComm App");
		PropertyConfigurator.configure(".\\testData\\log4j.properties");
		
		
		log.info("--------------info----------------");
		log.warn("--------------warn----------------");
		log.error("--------------error----------------");
		
		
		log.info("launching chrome browser");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		
		driver.manage().window().maximize();
		
		log.info("launching application: " + Constants.sample_element_condition);
		driver.get(Constants.sample_element_condition);
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		
	}
	
	
	@AfterTest
	public void closeApp() throws Exception {
		log.info("closing an application: " );
		
		Thread.sleep(7000);
		driver.close();
		
		
	}
	
	
	@Test
	public void verifyLoginFeature() throws Exception {
		
		
		//sync issue
		//conditional wait
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("text3")));
		
		
		driver.findElement(By.id("text3")).sendKeys("enter value into textbox3");
		
	}

}
