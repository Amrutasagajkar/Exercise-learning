package actionExample;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DragDropTest {
	
	
WebDriver driver;
	
	@AfterTest
	public void closeApp() throws Exception {
		
		
		System.out.println("closing application");
		Thread.sleep(7000);
		driver.close();   //------- close current browser instance
		//driver.quit();  //------- close all browser instance
		
		
	}
	
	
		
	@BeforeTest
	public void launchApp() throws Exception {
		
		
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.get("https://www.globalsqa.com/demo-site/draganddrop/");
		Thread.sleep(5000);
		System.out.println("launching sample drag drop application");
	}
	
	
	@Test
	public void verifySearchItem() throws Exception {
		
		
		WebElement photoFrame = driver.findElement(By.cssSelector("iframe[data-src*='photo']"));
		driver.switchTo().frame(photoFrame);
		
		
		
		
		WebElement img3 = driver.findElement(By.cssSelector("img[src*='tatras3']"));
		WebElement img4 = driver.findElement(By.cssSelector("img[src*='tatras4']"));
		WebElement trash = driver.findElement(By.cssSelector("div#trash"));
		
		
		
		
		Actions act = new Actions(driver);
		
		//app1
		act.dragAndDrop(img3, trash).perform();
		
		
		Thread.sleep(4000);
		//A convenience method that performs click-and-hold at the location of the source element, 
		//moves to the location of the target element, then releases the mouse.
		
		//app2
		act.clickAndHold(img4).moveToElement(trash).release().perform();
		
		
		
	}
	
	
	
	
	

}
