package junitExample;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BaseTest {
	

	@After
	public void closeApp() {
		
		
		System.out.println("closing application");
	}
	
	
		
	@Before
	public void launchApp() {
		
		
		System.out.println("launching application");
	}

}
