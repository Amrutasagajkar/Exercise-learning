package basicTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

public class ReadExample {

	public static void main(String[] args) throws Exception {
		
		
		FileInputStream fis = new FileInputStream(".\\data.properties");
		
		Properties p = new Properties();
		
		p.load(fis);
		
		System.out.println(p.getProperty("nop_appURL_prod"));
		System.out.println(p.getProperty("username"));
		System.out.println(p.getProperty("password"));
		
		

	}

}
