package testNG_Example;

import org.testng.annotations.Test;

//import org.junit.Test;

public class AmazonTest {
	
	
	@Test
	public void searchTest() {
		
		System.out.println("test case -----searchTest");
		
	}
	
	

}
