package controlExample;

//import org.junit.Test;
import org.openqa.selenium.By;

import org.testng.annotations.Test;

public class HandleInputBox extends BaseTest{
	
	
	@Test
	public void InputBoxTest() {
		
		
		driver.findElement(By.cssSelector("input[name=fname]")).sendKeys("enter first name");
		//driver.findElement(By.cssSelector("input[name=lname]")).sendKeys("enter last name disabled");
		
	}

}
