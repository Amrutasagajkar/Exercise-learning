package controlExample;

import java.util.List;

//import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class HandleCheckbox_FindElements extends BaseTest{
	
	
	@Test
	public void verifyCheckbox() {
		
		//by default it perform action on first element
		//driver.findElement(By.cssSelector("[name='vehicle']")).click();				//multiple match ----3
		
		
		
		
		List<WebElement> all_vehicle =  driver.findElements(By.cssSelector("[name='vehicle']"));
		
		System.out.println("how many vechicle: " + all_vehicle.size());
		
		
//		all_vehicle.get(0).click();
//		all_vehicle.get(1).click();
		
		
		for (int i = 0; i < all_vehicle.size(); i++) {
			
			all_vehicle.get(i).click();
			
		}
		
		
	}
	
}
