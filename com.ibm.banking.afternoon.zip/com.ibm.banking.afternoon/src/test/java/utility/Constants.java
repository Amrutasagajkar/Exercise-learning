package utility;

public class Constants {
	
	
	
	public static final String nop_app = "https://admin-demo.nopcommerce.com/login?ReturnUrl=%2Fadmin%2F";
	public static final String nop_app_qa = "https://admin-demo.nopcommerce.com/login?ReturnUrl=%2Fadmin%2F";
	public static final String hrm_app = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	public static final String sample_alert = "http://only-testing-blog.blogspot.com/2014/01/new-testing.html?";
	public static final String sample_element_condition = "http://only-testing-blog.blogspot.com/2014/01/textbox.html";
	public static final String username = "admin@yourstore.com";
	public static final String password = "admin";
	public static final String api_key = "";

	
	public static final String URL = "https://demoqa.com/automation-practice-form";
    public static final String Path_TestData = ".\\data\\";
    public static final String File_TestData = "RegisterStudent.xls";
    public static final String File_TestData2 = "RegistrationData.xlsx";
    public static final String URI_API_SAMPLE = "https://reqres.in";
    public static final String apiKey = "c76e6d1f2e6af75573c66176b1ad5627";

	
}
