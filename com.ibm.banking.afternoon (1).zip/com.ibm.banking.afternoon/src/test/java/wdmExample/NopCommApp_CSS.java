package wdmExample;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NopCommApp_CSS {
	
	//crtl+shift+O ---- add import/remove unused imports
	WebDriver driver;
	
	@Before
	public void launchApp() {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("https://admin-demo.nopcommerce.com/login?ReturnUrl=%2Fadmin%2F");
		
	}
	
	@After
	public void closeApp() throws Exception {
		Thread.sleep(5000);
		System.out.println("closing application");
		driver.close();
	}
	
	
	@Test
	public void verifyLogin() throws Exception {
		Thread.sleep(4000);
//		WebElement txtEmail = driver.findElement(By.xpath("//input[@type=\"email\"]"));
		WebElement txtEmail = driver.findElement(By.cssSelector("input[type='email']"));
		txtEmail.clear();
		
		Thread.sleep(4000);
		txtEmail.sendKeys("admin@yourstore.com");
		
		
		
		driver.findElement(By.cssSelector("input[value='admin']")).clear();
		driver.findElement(By.cssSelector("input[value='admin']")).sendKeys("admin");
		
		
		driver.findElement(By.cssSelector("[type=\"checkbox\"]")).click();
		
		
		driver.findElement(By.cssSelector("[type=\"submit\"]")).click();
		
		
		System.out.println("--------------after login------------------------");
		System.out.println("Applciation Title: " + driver.getTitle());
		System.out.println("Applciation URL: " + driver.getCurrentUrl());
		
		Thread.sleep(4000);
		driver.findElement(By.cssSelector("a[href='/logout']")).click();
		
		Thread.sleep(4000);
		System.out.println("--------------after logout------------------------");
		System.out.println("Applciation Title: " + driver.getTitle());
		System.out.println("Applciation URL: " + driver.getCurrentUrl());
		
	}

}
