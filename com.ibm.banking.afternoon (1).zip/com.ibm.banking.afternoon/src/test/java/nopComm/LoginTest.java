package nopComm;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest {
	
	
	
	@Test
	public void verifyLoginFeature() throws Exception {
		
		
		//app1
//		System.setProperty("", "");
		
		
		
		//app2
		//webdrivermanager
		//WebDriverManager.chromedriver().setup();
		
		
		
		
		//app3 ----- launch and close
//		WebDriver driver = WebDriverManager.chromedriver().create();
//		Thread.sleep(5000);
		
		
		
		//app4 ----- latest version of selenium
		WebDriver driver = new ChromeDriver();
		
		
		
	}
	
	
	

}
