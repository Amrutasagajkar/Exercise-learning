package junitExample;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HRMLogin extends BaseTest{
	
	//execution workflow  ------launchApp ------verifyLoginFeature------closeApp
	
	//Unit testing framework
	//Test
	//pre-condition ------ Before
	//post-condition------ After
	
	
	
//	
//	@After
//	public void closeApp() {
//		
//		
//		System.out.println("closing application");
//	}
//	
	
	@Test
	public void verifyLoginFeature() {
		
		//hrm login and logout
	
		System.out.println("login test case");
		
		
	}
	
//	
//	@Before
//	public void launchApp() {
//		
//		
//		System.out.println("launching application");
//	}

}
