package handleSyncIssue_ConditionalWait;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import utility.Constants;

public class HRMLoginTest {
	WebDriver driver;
	Logger log;
	
	@BeforeTest
	public void launchApp() throws Exception {
		
		
		//log configuration
		
		log = Logger.getLogger("nopComm App");
		PropertyConfigurator.configure(".\\testData\\log4j.properties");
		
		
		log.info("--------------info----------------");
		log.warn("--------------warn----------------");
		log.error("--------------error----------------");
		
		
		log.info("launching chrome browser");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		
		driver.manage().window().maximize();
		
		log.info("launching application: " + Constants.hrm_app);
		driver.get(Constants.hrm_app);
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
	}
	
	
	@AfterTest
	public void closeApp() throws Exception {
		log.info("closing an application: " );
		
		Thread.sleep(7000);
		driver.close();
		
		
	}
	
	
	@Test
	public void verifyLoginFeature() {
		
		
		//sync issue
		
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		
		driver.findElement(By.tagName("button")).click();
		
		
		driver.findElement(By.className("oxd-userdropdown-tab")).click();
		
		driver.findElement(By.partialLinkText("Logout")).click();
		
		
	}

}
