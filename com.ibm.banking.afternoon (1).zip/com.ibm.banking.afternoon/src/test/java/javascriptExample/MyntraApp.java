package javascriptExample;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MyntraApp {
	
	
WebDriver driver;
	
	@AfterTest
	public void closeApp() throws Exception {
		
		
		System.out.println("closing application");
		Thread.sleep(7000);
		driver.close();   //------- close current browser instance
		//driver.quit();  //------- close all browser instance
		
		
	}
	
	
		
	@BeforeTest
	public void launchApp() throws Exception {
		
		
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.get("https://www.myntra.com/");
		Thread.sleep(5000);
		System.out.println("launching paytm application");
	}
	
	
	@Test
	public void verifyPayTM() throws Exception {
		
		
		WebElement ele_ReturnPolicy = driver.findElement(By.xpath("//strong[contains(text(),'Return within 14days')]"));
		
		JavascriptExecutor JS = (JavascriptExecutor) driver;
		

		JS.executeScript("arguments[0].scrollIntoView()", ele_ReturnPolicy);
		
		
		
		
		
		
	}

}
