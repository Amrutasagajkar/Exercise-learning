package retryLogic;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HRMLogin {

	static WebDriver driver;

	@AfterTest
	public void closeApp() throws Exception {

		System.out.println("closing application");
		Thread.sleep(7000);
		driver.close(); // ------- close current browser instance
		// driver.quit(); //------- close all browser instance

	}

	@BeforeTest
	public void launchApp() throws Exception {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		Thread.sleep(5000);
		System.out.println("launching sample drag drop application");
	}

	@Test(priority = 1)
	public void verifySearchItem() throws Exception {

		driver.findElement(By.name("username")).sendKeys("Admin");

		driver.findElement(By.name("password")).sendKeys("admin123");

		driver.findElement(By.tagName("button")).click();

		Thread.sleep(4000);

	}

	@Test(priority = 2)
	public void logoutTest() throws Exception {

		driver.findElement(By.cssSelector(".oxd-userdropdown-name")).click();
		Thread.sleep(3000);
		driver.navigate().refresh();

		driver.findElement(By.partialLinkText("sdaoshdajsdja")).click();
		
		
		Thread.sleep(3000);
	}

}
