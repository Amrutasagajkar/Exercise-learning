package retryLogic;

import org.testng.Assert;
import org.testng.annotations.Test;

public class AmazonTest {
	
	
	@Test
	public void addItem() {
		 
		System.out.println("addItem test case");
		
	}
	
	@Test
	public void login() {
		 
		System.out.println("login test case");
		
	}
	
	
	@Test
	public void logout() {
		 
		System.out.println("logout test case");
		

//		String expectedTitle = "Amazon.in";
//		String actualTitle = "Amazon.com";
//		
//		Assert.assertEquals(actualTitle, expectedTitle);
		
	}
	
	
	//@Test(retryAnalyzer = retryLogic.RetryLogic.class)
	
	@Test
	public void payment() {
		 
		System.out.println("payment test case");
		
		String expectedTitle = "Amazon.in";
		String actualTitle = "Amazon.com";
		
		Assert.assertEquals(actualTitle, expectedTitle);
	}
	
	
	

}
