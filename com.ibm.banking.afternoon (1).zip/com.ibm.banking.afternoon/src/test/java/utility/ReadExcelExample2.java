package utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelExample2 {

	public static void main(String[] args) throws Exception {
		
		
		FileInputStream fis = new FileInputStream(".//testData//testData.xlsx");
		
		
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		
		
		XSSFSheet sheet = workbook.getSheet("sample");
//		workbook.getSheetAt(0);
		
		int columnCount =  sheet.getRow(0).getLastCellNum();
		
		
		
		int rowCount = sheet.getLastRowNum();
		
		System.out.println("Rows count are: " + rowCount);
		System.out.println("columnCount  are: " + columnCount);
		
		
		
		
		for (int row = 1; row <= rowCount; row++) {
			
			String name = sheet.getRow(row).getCell(0).toString();
			
			System.out.println(name);
		}
		
		

	}

}
