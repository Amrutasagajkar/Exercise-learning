package controlExample;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

public class HandleAlert extends BaseTest{
	
	
	
	
	

	//@Test()
	public void handleSimpleAlert() throws InterruptedException {
		
		Thread.sleep(2000);
		
		
		driver.findElement(By.cssSelector("input[value='Show Me Alert']")).click();;      
		
		
		
		//handle an alert
		//Alert/Iframe/windows    ------  driver.switchTo()
		
		
		//Alert example
		
		//accept() ----- OK
		//dismiss()----- cancel button/esc
		//getText()
		//SendKeys()
		
		
		
	
		Alert simpleAlert = driver.switchTo().alert();
		
		String alertText = simpleAlert.getText();
		System.out.println("Alert Text: " + alertText);
		
		
		
		//Assertion
		String expectedAlert = "Hi.. This is alert message!";
		
		if(expectedAlert.equals(alertText)){
			
			
			System.out.println("--------validation pass---------");
		}
		
		else {
			
			System.out.println("--------validation failed---------");
		}
		
		
		
		Assert.assertEquals(alertText,expectedAlert);			//pass
		
		
		Thread.sleep(5000);
//		simpleAlert.accept();
		
		
		simpleAlert.dismiss();
		
		Thread.sleep(5000);
	}
	
	
	
	//@Test
	public void handleConfirmAlert() throws InterruptedException {
		
		Thread.sleep(2000);
		
		
		driver.findElement(By.cssSelector("button[onclick='myFunction()']")).click();      
		
		
		
		//handle an alert
		//Alert/Iframe/windows    ------  driver.switchTo()
		
		
		//Alert example
		
		//accept() ----- OK
		//dismiss()----- cancel button/esc
		//getText()
		//SendKeys()
		
		
		
	
		Alert confirmAlert = driver.switchTo().alert();
		
		String actualAlertText = confirmAlert.getText();
		System.out.println("Confirm Alert Text: " + actualAlertText);
		
		
		
		//Assertion
		String expectedAlertText = "Press 'OK' or 'Cancel' button!";
		
		
		Assert.assertEquals(actualAlertText,expectedAlertText);			//pass
		
		
		Thread.sleep(5000);
		confirmAlert.accept();
		
		
		//confirmAlert.dismiss();
		
		
		String actualActionOnAlertText = driver.findElement(By.id("demo")).getText();
		System.out.println("perform action ok/Cancel: " + actualActionOnAlertText);
		
		Thread.sleep(5000);
	}
	
	
	
	@Test
	public void handlePromptAlert() throws InterruptedException {
		
		Thread.sleep(2000);
		
		
		driver.findElement(By.cssSelector("button[onclick='myFunctionf()']")).click();      
		
		
		
		//handle an alert
		//Alert/Iframe/windows    ------  driver.switchTo()
		
		
		//Alert example
		
		//accept() ----- OK
		//dismiss()----- cancel button/esc
		//getText()
		//SendKeys()
		
		
		
	
		Alert promptAlert = driver.switchTo().alert();
		
		String actualAlertText = promptAlert.getText();
		System.out.println("Prompt Alert Text: " + actualAlertText);
		
		
		
		//Assertion
		String expectedAlertText = "Your Name Please";
		
		
		Assert.assertEquals(actualAlertText,expectedAlertText);			//pass
		
		
		Thread.sleep(5000);
		
		
		promptAlert.sendKeys("Abhishek");
		
		
		
		
		promptAlert.accept();
		
		
		
		Thread.sleep(5000);
	}
}
