package controlExample;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HandleAlertDemoApp extends BaseTest{
	
	
WebDriver driver;
	
	@AfterTest
	public void closeApp() throws Exception {
		
		
		System.out.println("closing application");
		Thread.sleep(7000);
		driver.close();   //------- close current browser instance
		//driver.quit();  //------- close all browser instance
		
		
	}
	
	
		
	@BeforeTest
	public void launchApp() throws Exception {
		
		
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.get("file:///C:/Users/91995/Downloads/Test.html");
		Thread.sleep(5000);
		System.out.println("launching application");
	}

	
	
	
	
	@Test
	public void handlePromptAlert() throws InterruptedException {
		
		Thread.sleep(2000);
		
		
		driver.findElement(By.cssSelector("button[onclick=\"generatePromptBox()\"]")).click();      
		
		
		
		//handle an alert
		//Alert/Iframe/windows    ------  driver.switchTo()
		
		
		//Alert example
		
		//accept() ----- OK
		//dismiss()----- cancel button/esc
		//getText()
		//SendKeys()
		
		
		
	
		Alert promptAlert = driver.switchTo().alert();
		
		String actualAlertText = promptAlert.getText();
		System.out.println("Prompt Alert Text: " + actualAlertText);			//Please enter your name:
		
		
		
		//Assertion
		String expectedAlertText = "Please enter your name:";
		
		
		Assert.assertEquals(actualAlertText,expectedAlertText);			//pass
		
		
		Thread.sleep(5000);
		
	
		String name = "Janaki Nallakkukala";
		
		promptAlert.sendKeys(name);
		
		
		
		
		promptAlert.accept();
		
		
		
		Thread.sleep(5000);
	}
}
