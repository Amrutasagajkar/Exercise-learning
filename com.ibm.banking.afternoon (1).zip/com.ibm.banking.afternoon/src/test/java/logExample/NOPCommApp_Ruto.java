package logExample;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import utility.Constants;

public class NOPCommApp_Ruto  extends BaseTest{
	
	
	@Test
	public void verifyLogin() {
		
		driver.findElement(By.cssSelector("input#Email")).clear();
		driver.findElement(By.cssSelector("input#Email")).sendKeys(Constants.username);
		
		driver.findElement(By.cssSelector("input#Password")).clear();
		driver.findElement(By.cssSelector("input#Password")).sendKeys(Constants.password);
		
		
		
		driver.findElement(By.cssSelector("input#RememberMe")).click();
		
		driver.findElement(By.tagName("button")).click();
		
		
		System.out.println("============================application Title: " + driver.getTitle());
		
		Assert.assertEquals(driver.getTitle(), "Dashboard / nopCommerce administration");
		
	}

}
