package actionExample;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RightClickDoubleClickTest {
	
	
WebDriver driver;
	
	@AfterTest
	public void closeApp() throws Exception {
		
		
		System.out.println("closing application");
		Thread.sleep(7000);
		driver.close();   //------- close current browser instance
		//driver.quit();  //------- close all browser instance
		
		
	}
	
	
		
	@BeforeTest
	public void launchApp() throws Exception {
		
		
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.get("https://demo.guru99.com/test/simple_context_menu.html");
		Thread.sleep(5000);
		System.out.println("launching Sample application");
	}
	
	
	@Test
	public void rightClickTest() throws Exception {
		
		
		WebElement btnRightClick = driver.findElement(By.xpath("//span[contains(text(),'right')]"));
		//WebElement btnDoubleClick = driver.findElement(By.xpath("//button[contains(text(),'Double')]"));
		
		
		
		
		Actions act = new Actions(driver);
		
		
		//app1
		act.moveToElement(btnRightClick).contextClick().perform();
		
		
		//app2
		act.contextClick(btnRightClick).perform();
		
	}
	
	
	
	@Test
	public void doubleClickTest() throws Exception {
		
		
		//WebElement btnRightClick = driver.findElement(By.xpath("//span[contains(text(),'right')]"));
		WebElement btnDoubleClick = driver.findElement(By.xpath("//button[contains(text(),'Double')]"));
		
		
		
		
		Actions act = new Actions(driver);
		
		
		
		
		//app2
		act.doubleClick(btnDoubleClick).perform();
		
		
		Thread.sleep(6000);
		
		driver.switchTo().alert().dismiss();
		
	}
	
	
	
	

}
