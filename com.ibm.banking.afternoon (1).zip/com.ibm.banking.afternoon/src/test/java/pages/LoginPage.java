package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginPage {

	WebDriver driver;

	public LoginPage(WebDriver rdriver) {

		//this.driver = driver;
		
		driver = rdriver;
		
		PageFactory.initElements(rdriver, this);

	}

	// Identifications

	
	@FindBy(css = "input#Email")
	WebElement txt_Email;
	
	
	@FindBy(how = How.CSS, using = "input#Email")
	WebElement txt_Email1;
	
	
	@FindBy(css = "input#Password")
	WebElement txt_Pass;
	
	
	@FindBy(css = "input#RememberMe")
	WebElement chk_rem;
	
	@FindBy(tagName =   "button")
	WebElement btn_Login;
	
	
	@FindBy(partialLinkText  =   "Logout")
	WebElement btn_Logout;
	
	
	
	// Methods/Action

	public void enterEmail(String email) {

		// driver is null
		txt_Email.clear();
		txt_Email.sendKeys(email);
		
		txt_Email1.clear();
		txt_Email1.sendKeys(email);

	}

	public void enterPass(String pwd) {

		txt_Pass.clear();
		txt_Pass.sendKeys(pwd);

	}

	public void clickRemCheckbox() {

		chk_rem.click();
	}

	public void clickLoginButton() {

		btn_Login.click();
	}

	public void clickLogoutButton() {

		btn_Logout.click();
	}
	
	
	public void verifyApplicationTitle(String expTitle) throws Exception {

		Thread.sleep(3000);
		Assert.assertEquals(driver.getTitle(), expTitle);
	}
	
	public boolean verifyEmailDisplayed() {

		return txt_Email.isDisplayed();
	}

}
