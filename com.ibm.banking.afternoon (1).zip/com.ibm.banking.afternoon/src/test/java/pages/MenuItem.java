package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class MenuItem {

	WebDriver driver;

	public MenuItem(WebDriver rdriver) {

		//this.driver = driver;
		
		driver = rdriver;
		
		PageFactory.initElements(rdriver, this);

	}

	// Identifications

	
	@FindBy(css = "input#Email")
	WebElement txt_Email;
	
	
	@FindBy(how = How.CSS, using = "input#Email")
	WebElement txt_Email1;
	
	
	
	
	@FindBy(how = How.ID, using="SearchEmail")
	private WebElement searchEmail;
	
	
	@FindBy(how = How.ID, using="search-customers")
	private WebElement search;
	
	
	
	public void clickOnSearch(){
		
		
		
	}
	
	
	public void enterOnSearchEmail(String email){
		
		
		
	}
	
	
	
	
	
	
	
	// Methods/Action

	public void enterEmail(String email) {

		// driver is null
		txt_Email.clear();
		txt_Email.sendKeys(email);
		
		txt_Email1.clear();
		txt_Email1.sendKeys(email);

	}

	
	
	

}
