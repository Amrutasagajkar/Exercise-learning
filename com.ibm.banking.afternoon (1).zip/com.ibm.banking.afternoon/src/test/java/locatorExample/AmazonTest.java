package locatorExample;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonTest {

	
	WebDriver driver;

	@After
	public void closeApp() throws Exception {
		
		
		System.out.println("closing application");
		Thread.sleep(5000);
		driver.close();   //------- close current browser instance
		//driver.quit();  //------- close all browser instance
		
		
	}
	
	
		
	@Before
	public void launchApp() throws Exception {
		
		
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.get("https://www.amazon.in/");
		Thread.sleep(5000);
		System.out.println("launching application");
	}
	
	@Test
	public void searchTest() {
		
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("iphone 14");
		
	}
	
}
