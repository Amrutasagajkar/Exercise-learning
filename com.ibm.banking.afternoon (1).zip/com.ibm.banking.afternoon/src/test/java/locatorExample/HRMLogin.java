package locatorExample;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class HRMLogin extends BaseTest{
	

	@Test
	public void verifyLoginFeature() throws Exception {
		
		//locator
//		id
//		name
//		className
//		TagName
//
//
//		LinkText
//		PartialLinkText
//
//
//		XPATH
//		CSS Selector
		
		
		//hrm login and logout
	
		System.out.println("login test case");
		
		
		//name ---username/password
		WebElement txtUserName = driver.findElement(By.name("username"));
		txtUserName.sendKeys("Admin");
		
		driver.findElement(By.name("password")).sendKeys("admin123");
		
		
		
		//tagname---- login button
		driver.findElement(By.tagName("button")).click();
		
		Thread.sleep(5000);
		
//		validation step
		
		String appURL = driver.getCurrentUrl();
		System.out.println("Actual application URL after login: " + appURL);
		
		
		//tagname---- login button
		String actualText = driver.findElement(By.tagName("h6")).getText();
		System.out.println("Actual Text after login: " + actualText);
		
		
		
		//className ----- user dropdown
		driver.findElement(By.className("oxd-userdropdown-name")).click();
		
		Thread.sleep(5000);
		//linktext
		//driver.findElement(By.linkText("Logout")).click();
		
		
		
		//partialLinkText
		driver.findElement(By.partialLinkText("Logo")).click();
		
		
	}
	

}
