package handleFrame;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PayTMExample {
	
	
WebDriver driver;
	
	@AfterTest
	public void closeApp() throws Exception {
		
		
		System.out.println("closing application");
		Thread.sleep(7000);
		driver.close();   //------- close current browser instance
		//driver.quit();  //------- close all browser instance
		
		
	}
	
	
		
	@BeforeTest
	public void launchApp() throws Exception {
		
		
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.get("https://paytm.com/");
		Thread.sleep(5000);
		System.out.println("launching paytm application");
	}
	
	
	@Test
	public void verifyPayTM() throws Exception {
		
		
		WebElement btn_SignIn = driver.findElement(By.xpath("//span[contains(text(),'ign I')]"));
		btn_SignIn.click();
		
		
		
		//concept ----- frame
		//index ---- start from 0
		//name or id
		//webelement
		
		//index
//		driver.switchTo().frame(0);
//		
//		//name or id
//		driver.switchTo().frame("name / id ");
		

		WebElement myFrame = driver.findElement(By.cssSelector("[src*='paytm-web']"));
		driver.switchTo().frame(myFrame);
		
		
		
		
		Thread.sleep(5000);
		
		
		
		String heading = driver.findElement(By.cssSelector(".heading")).getText();
		System.out.println("payTM heading: " + heading);
		
		
		Assert.assertEquals(heading, "To Login into your Paytm Web account");
		
		WebElement linkWatchVideo = driver.findElement(By.xpath("//span[contains(text(),'Watch Video')]"));
		linkWatchVideo.click();
		
		
	}

}
