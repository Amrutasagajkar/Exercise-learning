package handleWindows;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class IRCTCApp_Example {
	
	
WebDriver driver;
	
	@AfterTest
	public void closeApp() throws Exception {
		
		
		System.out.println("closing application");
		Thread.sleep(7000);
		//driver.close();   //------- close current browser instance
		driver.quit();  	//------- close all browser instance
		
		
	}
	
	
		
	@BeforeTest
	public void launchApp() throws Exception {
		
		
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.get("https://www.irctc.co.in/nget/train-search");
		Thread.sleep(5000);
		System.out.println("launching irctc application");
	}
	
	
	@Test
	public void verifyHotelBooking() throws Exception {
		
		
		String parent_win = driver.getWindowHandle();
		System.out.println("parent window id: " + parent_win);
		
		
//		Set<String> allWindow = driver.getWindowHandles();
//		int winCount = allWindow.size();
//		System.out.println("how many windows opened: " + winCount);
		
		
		System.out.println("-------------------before click on hotel----------------------");
		
		WebElement link_Hotel = driver.findElement(By.partialLinkText("HOTELS"));
		link_Hotel.click();
		
		System.out.println("-------------------after click on hotel----------------------");
		Set<String> allWindow = driver.getWindowHandles();
		int winCount = allWindow.size();
		System.out.println("how many windows opened: " + winCount);
		
		
		
		String main_win = (String)allWindow.toArray()[0];
		String hotelWin = (String)allWindow.toArray()[1];
		
		System.out.println("main_win window id: " + main_win);
		System.out.println("hotelWin window id: " + hotelWin);
		
		
		
		//switch to Hotel
		System.out.println("-------------------switch to hotel Window----------------------");
		
		driver.switchTo().window(hotelWin);
		
		Thread.sleep(6000);
		
		System.out.println("Application title: " + driver.getTitle());
		driver.findElement(By.partialLinkText("Login")).click();
		
		//driver.findElement(By.xpath("//a[text()='Login']")).click();
		
		Thread.sleep(4000);
		
		
		//switch to main
		System.out.println("-------------------switch to main Window----------------------");
				
		driver.switchTo().window(main_win);
				
		Thread.sleep(6000);
		System.out.println("Application title: " + driver.getTitle());
		driver.findElement(By.partialLinkText("CONTACT US")).click();
		Thread.sleep(4000);
		
		
		
		//switch to Hotel
		System.out.println("-------------------switch to hotel Window again, click on login button on model dialog----------------------");
				
		driver.switchTo().window(hotelWin);
				
		Thread.sleep(4000);
		System.out.println("Application title: " + driver.getTitle());
		
		
		driver.findElement(By.cssSelector("button[type=\"submit\"]")).click();
		
		
		
		
		
		
	}

}
