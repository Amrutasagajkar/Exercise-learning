package testNGListners;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import takescreenshotExample.AmazonSearchItem;

public class TestNGListnerExample  implements ITestListener{

	@Override
	public void onTestStart(ITestResult result) {
		
		
		System.out.println("execute test case started : " + result.getName());
		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		
		
		
		
	}

	@Override
	public void onTestFailure(ITestResult result) {
		
		
		System.out.println("capture a screenshot for failed test case: " + result.getName());
		System.out.println("================================================================");
		
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		
		
		
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		
		
	}

	@Override
	public void onStart(ITestContext context) {
		
		
	}

	@Override
	public void onFinish(ITestContext context) {
		
		
	}

}
